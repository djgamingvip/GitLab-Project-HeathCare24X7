package com.care.health;

import android.content.Context;
import android.graphics.*;
import android.util.AttributeSet;
import android.view.View;
import android.animation.ValueAnimator;
import android.view.animation.LinearInterpolator;
import java.util.Random;

public class EmergencyAnimationView extends View {

    private Paint crossPaint, borderPaint, ecgPaint;
    private float ecgOffset = 0f;
    private Random random = new Random();
    private float[] crossX, crossY, crossSpeed;
    private int crossCount = 10;
    private boolean emergencyMode = false;

    public EmergencyAnimationView(Context context) {
        super(context);
        init();
    }

    public EmergencyAnimationView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    private void init() {
        crossPaint = new Paint();
        crossPaint.setColor(Color.parseColor("#0096FF"));
        crossPaint.setAlpha(80);
        crossPaint.setTextSize(60f);

        borderPaint = new Paint();
        borderPaint.setColor(Color.parseColor("#0096FF"));
        borderPaint.setStyle(Paint.Style.STROKE);
        borderPaint.setStrokeWidth(4f);
        borderPaint.setAlpha(60);

        ecgPaint = new Paint();
        ecgPaint.setColor(Color.parseColor("#0096FF"));
        ecgPaint.setStyle(Paint.Style.STROKE);
        ecgPaint.setStrokeWidth(4f);
        ecgPaint.setAntiAlias(true);

        crossX = new float[crossCount];
        crossY = new float[crossCount];
        crossSpeed = new float[crossCount];

        for (int i = 0; i < crossCount; i++) {
            crossX[i] = random.nextInt(1000);
            crossY[i] = random.nextInt(1500);
            crossSpeed[i] = 2f + random.nextFloat() * 3f;
        }

        startAnimations();
    }

    private void startAnimations() {
        // ECG line movement
        ValueAnimator ecgAnimator = ValueAnimator.ofFloat(0f, 200f);
        ecgAnimator.setDuration(3000);
        ecgAnimator.setRepeatCount(ValueAnimator.INFINITE);
        ecgAnimator.setInterpolator(new LinearInterpolator());
        ecgAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                ecgOffset = ((Float) animation.getAnimatedValue()).floatValue();
                invalidate();
            }
        });
        ecgAnimator.start();

        // Floating cross animation loop
        postDelayed(new Runnable() {
            @Override
            public void run() {
                for (int i = 0; i < crossCount; i++) {
                    crossY[i] -= crossSpeed[i];
                    if (crossY[i] < -50) {
                        crossY[i] = getHeight() + 50;
                        crossX[i] = random.nextInt(getWidth());
                    }
                }
                invalidate();
                postDelayed(this, 30);
            }
        }, 30);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        int w = getWidth();
        int h = getHeight();

        // Floating crosses
        for (int i = 0; i < crossCount; i++) {
            canvas.drawText("✚", crossX[i], crossY[i], crossPaint);
        }

        // ECG line (bottom)
        Path ecg = new Path();
        ecg.moveTo(-ecgOffset, h - 100);
        for (int i = 0; i < w + 200; i += 40) {
            ecg.rLineTo(10, 0);
            ecg.rLineTo(5, -20);
            ecg.rLineTo(5, 20);
            ecg.rLineTo(20, 0);
        }
        canvas.drawPath(ecg, ecgPaint);

        // Border pulse
        borderPaint.setAlpha((int) (100 + 100 * Math.sin(System.currentTimeMillis() / 500.0)));
        canvas.drawRoundRect(5, 5, w - 5, h - 5, 20, 20, borderPaint);

        // Emergency alert overlay
        if (emergencyMode) {
            canvas.drawColor(Color.argb(70, 255, 50, 50));
        }
    }

    public void activateEmergencyMode() {
        emergencyMode = true;
        ecgPaint.setColor(Color.RED);
        borderPaint.setColor(Color.RED);
        invalidate();
    }
}