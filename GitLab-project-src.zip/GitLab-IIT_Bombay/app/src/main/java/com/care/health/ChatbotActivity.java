package com.care.health;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.google.firebase.FirebaseApp;
import de.hdodenhof.circleimageview.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;
import androidx.appcompat.app.AppCompatActivity;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import android.view.inputmethod.InputMethodManager;

public class ChatbotActivity extends AppCompatActivity {
	
	private String TAG = "";
	
	private ArrayList<HashMap<String, Object>> listmap = new ArrayList<>();
	private ArrayList<String> st = new ArrayList<>();
	
	private LinearLayout linear1;
	private LinearLayout linear2;
	private ListView listview1;
	private LinearLayout linear6;
	private LinearLayout linear4;
	private ImageView imageview1;
	private CircleImageView circleimageview1;
	private LinearLayout linear5;
	private TextView textview1;
	private TextView textview2;
	private EditText edittext1;
	private CircleImageView circleimageview2;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.chatbot);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		linear2 = findViewById(R.id.linear2);
		listview1 = findViewById(R.id.listview1);
		linear6 = findViewById(R.id.linear6);
		linear4 = findViewById(R.id.linear4);
		imageview1 = findViewById(R.id.imageview1);
		circleimageview1 = findViewById(R.id.circleimageview1);
		linear5 = findViewById(R.id.linear5);
		textview1 = findViewById(R.id.textview1);
		textview2 = findViewById(R.id.textview2);
		edittext1 = findViewById(R.id.edittext1);
		circleimageview2 = findViewById(R.id.circleimageview2);
	}
	
	private void initializeLogic() {
	}
	
	public void _extra() {
	}
	public static class AutoTypeTextView extends TextView {
		
		    public static int PRECISSION_LOW = 8;
		    public static int PRECISSION_MED = 9;
		    public static int PRECISSION_HIGH = 11;
		    
		    private int decryptionSpeed = 10;
		    private int encryptionSpeed = 10;
		    private int typingSpeed =100;
		    private int precision = 5;
		    private String animateEncryption = "";
		    private String animateDecryption = "";
		    private String animateTextTyping = "";
		    private String animateTextTypingWithMistakes = "";
		
		    private Handler handler;
		    private int counter=0;
		    private boolean misstakeFound = false;
		    private boolean executed = false;
		    private Random ran = new Random();
		    public String misstakeValues = "qwertyuiop[]asdfghjkl;zxcvbnm,./!@#$^&*()_+1234567890";
		    private String encryptedText;
		    private int countLetter=0;
		    private int cocatation=0;
		
		    public AutoTypeTextView(Context context) {
			        super(context);
			    }
		
		    public AutoTypeTextView(Context context, AttributeSet attrs) {
			        super(context, attrs);
			    }
		
		    private void setupAttributes() {
			        if(animateTextTyping!=null)
			            setTextAutoTyping(animateTextTyping);
			
			        if(animateTextTypingWithMistakes!=null) {
				            if (precision < 6)
				                precision = 6;
				            setTextAutoTypingWithMistakes(animateTextTypingWithMistakes, precision);
				        }
			
			        if(animateDecryption!=null)
			            animateDecryption(animateDecryption);
			
			        if(animateEncryption!=null)
			            animateEncryption(animateEncryption);
			    }
		
		    public void setTextAutoTyping(final String text) {
			        if(!executed) {
				            executed = true;
				            counter = 0;
				            handler = new Handler();
				            handler.postDelayed(new Runnable() {
					                @Override
					                public void run() {
						                    setText(text.substring(0, counter));
						                    counter++;
						                    if (text.length() >= counter) {
							                        postDelayed(this, getTypingSpeed());
							                    } else {
							                        executed = false;
							                    }
						                }
					            }, getTypingSpeed());
				        }
			    }
		
		    public void setTextAutoTypingWithMistakes(final String text, final int precission) {
			        if(!executed) {
				            executed = true;
				            counter = 0;
				            handler = new Handler();
				            ran = new Random();
				            handler.postDelayed(new Runnable() {
					                @Override
					                public void run() {
						                    int num = ran.nextInt(10) + 1;
						                    if (num > precission && counter > 1 && !misstakeFound) {
							                        setText(chooseTypeOfMistake(text, counter));
							                        counter--;
							                    } else {
							                        counter++;
							                        setText(text.substring(0, counter));
							                        misstakeFound = false;
							                    }
						                    if (text.length() > counter) {
							                        postDelayed(this, getTypingSpeed());
							                    } else {
							                        executed = false;
							                    }
						                }
					            }, getTypingSpeed());
				        }
			    }
		
		    public void animateDecryption(final String text) {
			        encryptedText = text;
			        ran = new Random();
			        handler = new Handler();
			        cocatation = ran.nextInt(10);
			        counter = 0;
			        countLetter = 0;
			        if(!executed) {
				            executed = true;
				            for(int i=0; i<text.length(); i++) {
					                encryptedText = replaceCharAt(encryptedText, i, misstakeValues.charAt(ran.nextInt(misstakeValues.length())));
					                setText(encryptedText);
					            }
				                handler = new Handler();
				                handler.postDelayed(new Runnable() {
					                    @Override
					                    public void run() {
						                        if(counter <= cocatation) {
							                            encryptedText = replaceCharAt(encryptedText,countLetter,misstakeValues.charAt(ran.nextInt(misstakeValues.length())));
							                            setText(encryptedText);
							                            counter++;
							                        } else {
							                            encryptedText = replaceCharAt(encryptedText, countLetter, text.charAt(countLetter));
							                            setText(encryptedText);
							                            countLetter++;
							                            cocatation = ran.nextInt(10);
							                            counter = 0;
							                        }
						                        if(text.length() > countLetter) {
							                            postDelayed(this, getDecryptionSpeed());
							                        } else {
							                            executed = false;
							                        }
						                    }
					                }, getDecryptionSpeed());
				        }
			    }
		
		    public void animateEncryption(final String text) {
			        encryptedText = text;
			        ran = new Random();
			        handler = new Handler();
			        cocatation = ran.nextInt(10);
			        counter = 0;
			        countLetter = 0;
			        if(!executed) {
				            executed = true;
				            handler = new Handler();
				            handler.postDelayed(new Runnable() {
					                @Override
					                public void run() {
						                    if(counter <= cocatation) {
							                        encryptedText = replaceCharAt(encryptedText,countLetter,misstakeValues.charAt(ran.nextInt(misstakeValues.length())));
							                        setText(encryptedText);
							                        counter++;
							                    } else {
							                        countLetter++;
							                        cocatation = ran.nextInt(10);
							                        counter = 0;
							                    }
						                    if(text.length() > countLetter) {
							                        postDelayed(this, getDecryptionSpeed());
							                    } else {
							                        executed = false;
							                    }
						                }
					            }, getDecryptionSpeed());
				        }
			    }
		
		    private String chooseTypeOfMistake(String text, int counter) {
			        int misstake = ran.nextInt(3)+1;
			        String result = text.substring(0,counter);
			        switch(misstake) {
				            case 1 :
				                result = text.substring(0,counter-1) + randomChar();
				                break;
				            case 2 :
				                switch (ran.nextInt(2)+1) {
					                    case 1:
					                        result = text.substring(0, counter - 1) + String.valueOf(text.charAt(counter)).toLowerCase();
					                        break;
					                    case 2:
					                        result = text.substring(0, counter-1) + String.valueOf(text.charAt(counter)).toUpperCase();
					                        break;
					                }
				                break;
				            case 3 :
				                result = text.substring(0, counter-1);
				                break;
				        }
			        misstakeFound = true;
			        return result;
			    }
		
		    private char randomChar() {
			        return misstakeValues.charAt(ran.nextInt(misstakeValues.length()));
			    }
		
		    public static String replaceCharAt(String text, int pos, char c) {
			        return text.substring(0, pos) + c + text.substring(pos + 1);
			    }
		
		    public int getTypingSpeed() {
			        return typingSpeed;
			    }
		
		    public void setTypingSpeed(int typingSpeed) {
			        this.typingSpeed = typingSpeed;
			    }
		
		    public int getDecryptionSpeed() {
			        return decryptionSpeed;
			    }
		
		    public void setDecryptionSpeed(int decryptionSpeed) {
			        this.decryptionSpeed = decryptionSpeed;
			    }
		
		    public int getEncryptionSpeed() {
			        return encryptionSpeed;
			    }
		
		    public void setEncryptionSpeed(int encryptionSpeed) {
			        this.encryptionSpeed = encryptionSpeed;
			    }
		
		    public boolean isRunning() {
			        return executed;
			    }
	}
	{
	}
	
	public class Listview1Adapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.chat, null);
			}
			
			final LinearLayout received = _view.findViewById(R.id.received);
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final TextView rm = _view.findViewById(R.id.rm);
			final TextView rt = _view.findViewById(R.id.rt);
			final LinearLayout send = _view.findViewById(R.id.send);
			final TextView sm = _view.findViewById(R.id.sm);
			final TextView st = _view.findViewById(R.id.st);
			
			send.setVisibility(View.GONE);
			received.setVisibility(View.GONE);
			if (listmap.get((int)_position).containsKey("me")) {
				sm.setText(listmap.get((int)_position).get("me").toString());
				send.setVisibility(View.VISIBLE);
			}
			if (listmap.get((int)_position).containsKey("bot")) {
				rm.setText(listmap.get((int)_position).get("bot").toString());
				received.setVisibility(View.VISIBLE);
			}
			received.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)15, 0xFFE6E5EB));
			send.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)15, 0xFF673AB7));
			send.setOnLongClickListener(new View.OnLongClickListener(){
				@Override
				public boolean onLongClick(View _view){
					{PopupMenu popup = new PopupMenu(ChatbotActivity.this, send);
								android.view.Menu menu = popup.getMenu();
						
						menu.add("Copy");
						menu.add("Delete");
						popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
							
											public boolean onMenuItemClick(android.view.MenuItem item) {
													switch (item.getTitle().toString()) {
															
															case "Copy":
									((ClipboardManager) getSystemService(getApplicationContext().CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("clipboard", _data.get((int)_position).get("me").toString()));
									return true;
									case "Delete":
									listmap.remove((int)(_position));
									return true;
									
															default: return false;
													}
											}
									});
						
						
						popup.show();}
					return false;
				}
			});
			
			return _view;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}