package com.care.health;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.Intent;
import android.content.res.*;
import android.graphics.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.airbnb.lottie.*;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import java.io.*;
import java.io.InputStream;
import java.text.*;
import java.util.*;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;

public class MainActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private LinearLayout linear1;
	private LottieAnimationView lottie1;
	private TextView textview1;
	private TextView textview2;
	private LinearLayout linear2;
	
	private Intent intent = new Intent();
	private TimerTask timer;
	private RequestNetwork internet;
	private RequestNetwork.RequestListener _internet_request_listener;
	private DatabaseReference userdata = _firebase.getReference("userdata");
	private ChildEventListener _userdata_child_listener;
	private FirebaseAuth auth;
	private OnCompleteListener<AuthResult> _auth_create_user_listener;
	private OnCompleteListener<AuthResult> _auth_sign_in_listener;
	private OnCompleteListener<Void> _auth_reset_password_listener;
	private OnCompleteListener<Void> auth_updateEmailListener;
	private OnCompleteListener<Void> auth_updatePasswordListener;
	private OnCompleteListener<Void> auth_emailVerificationSentListener;
	private OnCompleteListener<Void> auth_deleteUserListener;
	private OnCompleteListener<Void> auth_updateProfileListener;
	private OnCompleteListener<AuthResult> auth_phoneAuthListener;
	private OnCompleteListener<AuthResult> auth_googleSignInListener;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		lottie1 = findViewById(R.id.lottie1);
		textview1 = findViewById(R.id.textview1);
		textview2 = findViewById(R.id.textview2);
		linear2 = findViewById(R.id.linear2);
		internet = new RequestNetwork(this);
		auth = FirebaseAuth.getInstance();
		
		_internet_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				if ((FirebaseAuth.getInstance().getCurrentUser() != null)) {
					timer = new TimerTask() {
						@Override
						public void run() {
							runOnUiThread(new Runnable() {
								@Override
								public void run() {
									intent.setClass(getApplicationContext(), HomeActivity.class);
									startActivity(intent);
									finish();
								}
							});
						}
					};
					_timer.schedule(timer, (int)(2000));
				} else {
					timer = new TimerTask() {
						@Override
						public void run() {
							runOnUiThread(new Runnable() {
								@Override
								public void run() {
									intent.setClass(getApplicationContext(), LoginActivity.class);
									startActivity(intent);
									finish();
								}
							});
						}
					};
					_timer.schedule(timer, (int)(2000));
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				intent.setClass(getApplicationContext(), OfflineActivity.class);
				startActivity(intent);
			}
		};
		
		_userdata_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		userdata.addChildEventListener(_userdata_child_listener);
		
		auth_updateEmailListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_updatePasswordListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_emailVerificationSentListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_deleteUserListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_phoneAuthListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		auth_updateProfileListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_googleSignInListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		_auth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	
	private void initializeLogic() {
		linear2.addView(new AutoTypeTextView(MainActivity.this));
		((AutoTypeTextView)linear2.getChildAt((int)0)).setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,LinearLayout.LayoutParams.MATCH_PARENT));
		((AutoTypeTextView)linear2.getChildAt((int)0)).setTypingSpeed((int) 10);
		((AutoTypeTextView)linear2.getChildAt((int)0)).setTextAutoTyping("\"Caring for Life, Every Step of the Way...\"\nBringing Health & Technology Together");
		internet.startRequestNetwork(RequestNetworkController.GET, "https://google.com", "", _internet_request_listener);
		textview1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font_style.ttf"), 1);
		textview2.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font_style.ttf"), 1);
	}
	
	public void _extra() {
	}
	public static class AutoTypeTextView extends TextView {
		
		    public static int PRECISSION_LOW = 8;
		    public static int PRECISSION_MED = 9;
		    public static int PRECISSION_HIGH = 11;
		    
		    private int decryptionSpeed = 10;
		    private int encryptionSpeed = 10;
		    private int typingSpeed =100;
		    private int precision = 5;
		    private String animateEncryption = "";
		    private String animateDecryption = "";
		    private String animateTextTyping = "";
		    private String animateTextTypingWithMistakes = "";
		
		    private Handler handler;
		    private int counter=0;
		    private boolean misstakeFound = false;
		    private boolean executed = false;
		    private Random ran = new Random();
		    public String misstakeValues = "qwertyuiop[]asdfghjkl;zxcvbnm,./!@#$^&*()_+1234567890";
		    private String encryptedText;
		    private int countLetter=0;
		    private int cocatation=0;
		
		    public AutoTypeTextView(Context context) {
			        super(context);
			    }
		
		    public AutoTypeTextView(Context context, AttributeSet attrs) {
			        super(context, attrs);
			    }
		
		    private void setupAttributes() {
			        if(animateTextTyping!=null)
			            setTextAutoTyping(animateTextTyping);
			
			        if(animateTextTypingWithMistakes!=null) {
				            if (precision < 6)
				                precision = 6;
				            setTextAutoTypingWithMistakes(animateTextTypingWithMistakes, precision);
				        }
			
			        if(animateDecryption!=null)
			            animateDecryption(animateDecryption);
			
			        if(animateEncryption!=null)
			            animateEncryption(animateEncryption);
			    }
		
		    public void setTextAutoTyping(final String text) {
			        if(!executed) {
				            executed = true;
				            counter = 0;
				            handler = new Handler();
				            handler.postDelayed(new Runnable() {
					                @Override
					                public void run() {
						                    setText(text.substring(0, counter));
						                    counter++;
						                    if (text.length() >= counter) {
							                        postDelayed(this, getTypingSpeed());
							                    } else {
							                        executed = false;
							                    }
						                }
					            }, getTypingSpeed());
				        }
			    }
		
		    public void setTextAutoTypingWithMistakes(final String text, final int precission) {
			        if(!executed) {
				            executed = true;
				            counter = 0;
				            handler = new Handler();
				            ran = new Random();
				            handler.postDelayed(new Runnable() {
					                @Override
					                public void run() {
						                    int num = ran.nextInt(10) + 1;
						                    if (num > precission && counter > 1 && !misstakeFound) {
							                        setText(chooseTypeOfMistake(text, counter));
							                        counter--;
							                    } else {
							                        counter++;
							                        setText(text.substring(0, counter));
							                        misstakeFound = false;
							                    }
						                    if (text.length() > counter) {
							                        postDelayed(this, getTypingSpeed());
							                    } else {
							                        executed = false;
							                    }
						                }
					            }, getTypingSpeed());
				        }
			    }
		
		    public void animateDecryption(final String text) {
			        encryptedText = text;
			        ran = new Random();
			        handler = new Handler();
			        cocatation = ran.nextInt(10);
			        counter = 0;
			        countLetter = 0;
			        if(!executed) {
				            executed = true;
				            for(int i=0; i<text.length(); i++) {
					                encryptedText = replaceCharAt(encryptedText, i, misstakeValues.charAt(ran.nextInt(misstakeValues.length())));
					                setText(encryptedText);
					            }
				                handler = new Handler();
				                handler.postDelayed(new Runnable() {
					                    @Override
					                    public void run() {
						                        if(counter <= cocatation) {
							                            encryptedText = replaceCharAt(encryptedText,countLetter,misstakeValues.charAt(ran.nextInt(misstakeValues.length())));
							                            setText(encryptedText);
							                            counter++;
							                        } else {
							                            encryptedText = replaceCharAt(encryptedText, countLetter, text.charAt(countLetter));
							                            setText(encryptedText);
							                            countLetter++;
							                            cocatation = ran.nextInt(10);
							                            counter = 0;
							                        }
						                        if(text.length() > countLetter) {
							                            postDelayed(this, getDecryptionSpeed());
							                        } else {
							                            executed = false;
							                        }
						                    }
					                }, getDecryptionSpeed());
				        }
			    }
		
		    public void animateEncryption(final String text) {
			        encryptedText = text;
			        ran = new Random();
			        handler = new Handler();
			        cocatation = ran.nextInt(10);
			        counter = 0;
			        countLetter = 0;
			        if(!executed) {
				            executed = true;
				            handler = new Handler();
				            handler.postDelayed(new Runnable() {
					                @Override
					                public void run() {
						                    if(counter <= cocatation) {
							                        encryptedText = replaceCharAt(encryptedText,countLetter,misstakeValues.charAt(ran.nextInt(misstakeValues.length())));
							                        setText(encryptedText);
							                        counter++;
							                    } else {
							                        countLetter++;
							                        cocatation = ran.nextInt(10);
							                        counter = 0;
							                    }
						                    if(text.length() > countLetter) {
							                        postDelayed(this, getDecryptionSpeed());
							                    } else {
							                        executed = false;
							                    }
						                }
					            }, getDecryptionSpeed());
				        }
			    }
		
		    private String chooseTypeOfMistake(String text, int counter) {
			        int misstake = ran.nextInt(3)+1;
			        String result = text.substring(0,counter);
			        switch(misstake) {
				            case 1 :
				                result = text.substring(0,counter-1) + randomChar();
				                break;
				            case 2 :
				                switch (ran.nextInt(2)+1) {
					                    case 1:
					                        result = text.substring(0, counter - 1) + String.valueOf(text.charAt(counter)).toLowerCase();
					                        break;
					                    case 2:
					                        result = text.substring(0, counter-1) + String.valueOf(text.charAt(counter)).toUpperCase();
					                        break;
					                }
				                break;
				            case 3 :
				                result = text.substring(0, counter-1);
				                break;
				        }
			        misstakeFound = true;
			        return result;
			    }
		
		    private char randomChar() {
			        return misstakeValues.charAt(ran.nextInt(misstakeValues.length()));
			    }
		
		    public static String replaceCharAt(String text, int pos, char c) {
			        return text.substring(0, pos) + c + text.substring(pos + 1);
			    }
		
		    public int getTypingSpeed() {
			        return typingSpeed;
			    }
		
		    public void setTypingSpeed(int typingSpeed) {
			        this.typingSpeed = typingSpeed;
			    }
		
		    public int getDecryptionSpeed() {
			        return decryptionSpeed;
			    }
		
		    public void setDecryptionSpeed(int decryptionSpeed) {
			        this.decryptionSpeed = decryptionSpeed;
			    }
		
		    public int getEncryptionSpeed() {
			        return encryptionSpeed;
			    }
		
		    public void setEncryptionSpeed(int encryptionSpeed) {
			        this.encryptionSpeed = encryptionSpeed;
			    }
		
		    public boolean isRunning() {
			        return executed;
			    }
	}
	{
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}