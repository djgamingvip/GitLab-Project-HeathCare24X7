package com.care.health;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.Intent;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.airbnb.lottie.*;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import java.io.*;
import java.io.InputStream;
import java.text.*;
import java.util.*;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;
import androidX.Master12.AnimatedParticleView;

public class LoginActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private HashMap<String, Object> map = new HashMap<>();
	private String key = "";
	private boolean imageview_3 = false;
	
	private LinearLayout linear1;
	private LinearLayout linear2;
	private LinearLayout linear_font;
	private LottieAnimationView lottie1;
	private TextView textview1;
	private RelativeLayout back;
	private LinearLayout main;
	private LinearLayout linear3;
	private LinearLayout linear_name;
	private LinearLayout linear_email;
	private LinearLayout linear_pass;
	private LinearLayout linear4;
	private Button button1;
	private Button button2;
	private LinearLayout linear5;
	private ImageView imageview4;
	private EditText edittext3;
	private ImageView imageview1;
	private EditText edittext1;
	private ImageView imageview2;
	private EditText edittext2;
	private ImageView imageview3;
	private TextView textview2;
	private TextView textview3;
	private TextView textview4;
	
	private DatabaseReference userdata = _firebase.getReference("userdata");
	private ChildEventListener _userdata_child_listener;
	private FirebaseAuth auth;
	private OnCompleteListener<AuthResult> _auth_create_user_listener;
	private OnCompleteListener<AuthResult> _auth_sign_in_listener;
	private OnCompleteListener<Void> _auth_reset_password_listener;
	private OnCompleteListener<Void> auth_updateEmailListener;
	private OnCompleteListener<Void> auth_updatePasswordListener;
	private OnCompleteListener<Void> auth_emailVerificationSentListener;
	private OnCompleteListener<Void> auth_deleteUserListener;
	private OnCompleteListener<Void> auth_updateProfileListener;
	private OnCompleteListener<AuthResult> auth_phoneAuthListener;
	private OnCompleteListener<AuthResult> auth_googleSignInListener;
	private Intent intent = new Intent();
	private TimerTask timer;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.login);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		linear2 = findViewById(R.id.linear2);
		linear_font = findViewById(R.id.linear_font);
		lottie1 = findViewById(R.id.lottie1);
		textview1 = findViewById(R.id.textview1);
		back = findViewById(R.id.back);
		main = findViewById(R.id.main);
		linear3 = findViewById(R.id.linear3);
		linear_name = findViewById(R.id.linear_name);
		linear_email = findViewById(R.id.linear_email);
		linear_pass = findViewById(R.id.linear_pass);
		linear4 = findViewById(R.id.linear4);
		button1 = findViewById(R.id.button1);
		button2 = findViewById(R.id.button2);
		linear5 = findViewById(R.id.linear5);
		imageview4 = findViewById(R.id.imageview4);
		edittext3 = findViewById(R.id.edittext3);
		imageview1 = findViewById(R.id.imageview1);
		edittext1 = findViewById(R.id.edittext1);
		imageview2 = findViewById(R.id.imageview2);
		edittext2 = findViewById(R.id.edittext2);
		imageview3 = findViewById(R.id.imageview3);
		textview2 = findViewById(R.id.textview2);
		textview3 = findViewById(R.id.textview3);
		textview4 = findViewById(R.id.textview4);
		auth = FirebaseAuth.getInstance();
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				timer = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								if (button1.getText().toString().equals("Login")) {
									if (edittext1.getText().toString().equals("") || edittext2.getText().toString().equals("")) {
										SketchwareUtil.showMessage(getApplicationContext(), "Something went wrong !");
									} else {
										if (edittext1.getText().toString().contains("@gmail.com")) {
											auth.signInWithEmailAndPassword(edittext1.getText().toString(), edittext2.getText().toString()).addOnCompleteListener(LoginActivity.this, _auth_sign_in_listener);
										}
										else {
											SketchwareUtil.showMessage(getApplicationContext(), "Invalid Email !");
										}
									}
								}
								if (button1.getText().toString().equals("Send Link !")) {
									if (edittext1.getText().toString().equals("")) {
										SketchwareUtil.showMessage(getApplicationContext(), "Something went wrong !");
									} else {
										if (edittext1.getText().toString().contains("@gmail.com")) {
											auth.sendPasswordResetEmail(edittext1.getText().toString()).addOnCompleteListener(_auth_reset_password_listener);
										}
										else {
											SketchwareUtil.showMessage(getApplicationContext(), "Invalid Email !");
										}
									}
								}
							}
						});
					}
				};
				_timer.schedule(timer, (int)(2000));
			}
		});
		
		button2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				timer = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								if (edittext1.getText().toString().equals("") || (edittext2.getText().toString().equals("") || edittext3.getText().toString().equals(""))) {
									SketchwareUtil.showMessage(getApplicationContext(), "Something went wrong !");
								} else {
									if (edittext1.getText().toString().contains("@gmail.com")) {
										auth.createUserWithEmailAndPassword(edittext1.getText().toString(), edittext2.getText().toString()).addOnCompleteListener(LoginActivity.this, _auth_create_user_listener);
									}
									else {
										SketchwareUtil.showMessage(getApplicationContext(), "Invalid Email !");
									}
								}
							}
						});
					}
				};
				_timer.schedule(timer, (int)(2000));
			}
		});
		
		imageview3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
			}
		});
		
		textview2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				linear_pass.setVisibility(View.GONE);
				button2.setVisibility(View.GONE);
				linear5.setVisibility(View.GONE);
				button1.setText("Send Link !");
			}
		});
		
		textview4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (textview4.getText().toString().equals("Login")) {
					textview3.setText("Don't have an account ?");
					textview4.setText("SignUp");
					button1.setVisibility(View.VISIBLE);
					button2.setVisibility(View.GONE);
					linear_name.setVisibility(View.GONE);
					textview2.setVisibility(View.VISIBLE);
				} else {
					textview3.setText("Already have an account ?");
					textview4.setText("Login");
					button1.setVisibility(View.GONE);
					button2.setVisibility(View.VISIBLE);
					linear_name.setVisibility(View.VISIBLE);
					textview2.setVisibility(View.GONE);
				}
			}
		});
		
		_userdata_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		userdata.addChildEventListener(_userdata_child_listener);
		
		auth_updateEmailListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_updatePasswordListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_emailVerificationSentListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_deleteUserListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_phoneAuthListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		auth_updateProfileListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_googleSignInListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		_auth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				if (_success) {
					key = FirebaseAuth.getInstance().getCurrentUser().getUid();
					map = new HashMap<>();
					map.put("UID", key);
					map.put("name", edittext3.getText().toString());
					map.put("email", FirebaseAuth.getInstance().getCurrentUser().getEmail());
					map.put("doctor", "");
					map.put("password", edittext2.getText().toString());
					userdata.child(key).updateChildren(map);
					map.clear();
					intent.setClass(getApplicationContext(), HomeActivity.class);
					startActivity(intent);
				} else {
					SketchwareUtil.showMessage(getApplicationContext(), _errorMessage);
				}
			}
		};
		
		_auth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				if (_success) {
					intent.setClass(getApplicationContext(), HomeActivity.class);
					startActivity(intent);
				} else {
					SketchwareUtil.showMessage(getApplicationContext(), _errorMessage);
				}
			}
		};
		
		_auth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				if (_success) {
					SketchwareUtil.showMessage(getApplicationContext(), "Email Sent !");
					linear_pass.setVisibility(View.VISIBLE);
					button2.setVisibility(View.VISIBLE);
					linear5.setVisibility(View.VISIBLE);
					button1.setText("Login");
				}
			}
		};
	}
	
	private void initializeLogic() {
		int[] colorsA1 = { Color.parseColor("#FFFFFF"), Color.parseColor("#FFFFFF") }; android.graphics.drawable.GradientDrawable A1 = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colorsA1);
		A1.setCornerRadii(new float[]{(int)200,(int)200,(int)200,(int)200,(int)0,(int)0,(int)0,(int)0});
		A1.setStroke((int) 0, Color.parseColor("#607D8B"));
		linear_font.setElevation((float) 5);
		linear_font.setBackground(A1);
		
		//RIPPLE ROUND BLOCK BY DJ GAMING VIP
		int[] colorsA2 = { Color.parseColor("#00000000"), Color.parseColor("#00000000") }; android.graphics.drawable.GradientDrawable A2 = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colorsA2);
		A2.setCornerRadii(new float[]{(int)200,(int)200,(int)200,(int)200,(int)0,(int)0,(int)0,(int)0});
		A2.setStroke((int) 0, Color.parseColor("#607D8B"));
		back.setElevation((float) 5);
		back.setBackground(A2);
		
		//RIPPLE ROUND BLOCK BY DJ GAMING VIP
		
		{
					android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
					int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
					int clrs [] = {0xFFF3F4F6,0xFFF3F4F6};
					SketchUi= new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT, clrs);
					SketchUi.setCornerRadius(d*50);
					SketchUi.setStroke(d*2,0xFF78909C);
					linear_name.setElevation(d*10);
					android.graphics.drawable.RippleDrawable SketchUiRD = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{Color.TRANSPARENT}), SketchUi, null);
					linear_name.setBackground(SketchUiRD);
					linear_name.setClickable(false);
		}
		
		
		{
					android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
					int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
					int clrs [] = {0xFFF3F4F6,0xFFF3F4F6};
					SketchUi= new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT, clrs);
					SketchUi.setCornerRadius(d*50);
					SketchUi.setStroke(d*2,0xFF78909C);
					linear_email.setElevation(d*10);
					android.graphics.drawable.RippleDrawable SketchUiRD = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{Color.TRANSPARENT}), SketchUi, null);
					linear_email.setBackground(SketchUiRD);
					linear_email.setClickable(false);
		}
		
		
		{
					android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
					int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
					int clrs [] = {0xFFF3F4F6,0xFFF3F4F6};
					SketchUi= new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT, clrs);
					SketchUi.setCornerRadius(d*50);
					SketchUi.setStroke(d*2,0xFF78909C);
					linear_pass.setElevation(d*10);
					android.graphics.drawable.RippleDrawable SketchUiRD = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{Color.TRANSPARENT}), SketchUi, null);
					linear_pass.setBackground(SketchUiRD);
					linear_pass.setClickable(false);
		}
		
		
		{
					android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
					int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
					int clrs [] = {0xFF8B5CF6,0xFF8B5CF6};
					SketchUi= new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT, clrs);
					SketchUi.setCornerRadius(d*50);
					SketchUi.setStroke(d*2,0xFF78909C);
					button1.setElevation(d*10);
					android.graphics.drawable.RippleDrawable SketchUiRD = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{Color.TRANSPARENT}), SketchUi, null);
					button1.setBackground(SketchUiRD);
					button1.setClickable(true);
		}
		
		
		{
					android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
					int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
					int clrs [] = {0xFF8B5CF6,0xFF8B5CF6};
					SketchUi= new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT, clrs);
					SketchUi.setCornerRadius(d*50);
					SketchUi.setStroke(d*2,0xFF78909C);
					button2.setElevation(d*10);
					android.graphics.drawable.RippleDrawable SketchUiRD = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{Color.TRANSPARENT}), SketchUi, null);
					button2.setBackground(SketchUiRD);
					button2.setClickable(true);
		}
		
		AnimatedParticleView particleView = new AnimatedParticleView(LoginActivity.this);
		particleView.setLineColor(0xFF673AB7);
		particleView.setparticleCount(20);
		particleView.setBackgroundColor(Color.TRANSPARENT);
		particleView.setParticleColor(0xFF673AB7);
		particleView.setParticleRadiusRange(5.0f, 10.0f);
		particleView.setAnimationMode(AnimatedParticleView.MODE_BOUNCE); // বা MODE_BOUNCE, MODE_EXPLODE, MODE_WAVE,MODE_SWIRL
		
		// layout এর মধ্যে যোগ করুন
		//import androidX.Master12.AnimatedParticleView;
		main.addView(particleView);
		button2.setVisibility(View.GONE);
		linear_name.setVisibility(View.GONE);
		final boolean[] isToggledimageview3 = {false};
		
		imageview3.setOnClickListener(new View.OnClickListener() {
			    @Override
			    public void onClick(View v) {
				        isToggledimageview3[0] = !isToggledimageview3[0];
				        if (isToggledimageview3[0]) {
					            edittext2.setTransformationMethod(android.text.method.HideReturnsTransformationMethod.getInstance());
					imageview3.setImageResource(R.drawable.ic_visibility_off_grey);
					        } else {
					            edittext2.setTransformationMethod(android.text.method.PasswordTransformationMethod.getInstance());
					imageview3.setImageResource(R.drawable.ic_remove_red_eye_grey);
					        }
				    }
		});
	}
	
	public void _loadingdialog(final boolean _ifShow, final String _title) {
		if (_ifShow) {
			if (prog == null){
				prog = new ProgressDialog(this);
				prog.setMax(100);
				prog.setIndeterminate(true);
				prog.setCancelable(false);
				prog.setCanceledOnTouchOutside(false);
			}
			prog.setMessage(_title);
			prog.show();
			
		} else {
			if (prog != null){
				prog.dismiss();
			}
			
			
		}
	} private ProgressDialog prog; {
		
		
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}